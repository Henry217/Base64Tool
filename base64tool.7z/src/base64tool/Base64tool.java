package base64tool;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.Base64;
import java.util.UUID;
import java.io.UnsupportedEncodingException;

public class Base64tool {
    private JPanel panel1;


    private JButton button1;


    private JComboBox comboBox1;
    public  static JFrame frame = new JFrame("Base64tool by henry217");

    public static void main(String[] args) {


        frame.setContentPane(new Base64tool().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private JCheckBox topMostCheckBox;
    private JTextArea textArea1;

    public Base64tool() {
        topMostCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(topMostCheckBox.isSelected()){
                    frame.setAlwaysOnTop(true);

                }
                else{
                    frame.setAlwaysOnTop(false);

                }
            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(comboBox1.getSelectedItem()=="Encode"){
                    String str=textArea1.getText();
                    try {
                        String base64encodedString = Base64.getEncoder().encodeToString(str.getBytes("utf-8"));
                        textArea1.setText(base64encodedString);
                    }
                    catch (Exception ex){
                        JOptionPane.showMessageDialog(null,ex.toString());
                    }

                }
                else
                {
                    String str=textArea1.getText();
                    try {
                        byte[] base64decodedBytes = Base64.getDecoder().decode(textArea1.getText());
                        textArea1.setText(new String(base64decodedBytes,"utf-8"));
                    }
                    catch (Exception ex){
                        JOptionPane.showMessageDialog(null,"请勿尝试解码非Base64字符串\n请去除所有空格，回车后重试");
                    }

                }
            }
        });
        panel1.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                super.componentShown(e);
                button1.setFocusPainted(false);
                button1.setBorderPainted(false);
            }
        });
    }
}
